/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package joao.exemplos;

/**
 *
 * @author endri
 */
public class exemplo2 {
    public static void main(String[] args) {
        //declara um int e atribui valor
        int idade = 25;
        //declara um float e, depois, atribui um valor
        float valor;
        valor = 1.99f;
        //declarando boolean
        boolean VerdadeiroOuFalso = false;
        VerdadeiroOuFalso = true;
        //declarando um char
        char letraA = 'a';
        letraA = 65; // ASCII para A
        letraA = '\u0041';  //unicode paea A
        // declarando um byte
        byte b = 127;
        //declarando um short
        short s = 1234;
        // declarando um long
        long i = 1234567890;
        //declara um double
        double d =100.0;
        //declarando multipla
        int va1=0, var2=1, var3=2, var4=3;
        
        
    }
}
